/*------------------------------------------------------------
// AUTHOR: Sebastian Chengattu
// FILENAME: main.cpp
// SPECIFICATION: your own description of the program.
// FOR: CSE 100- Lab #8
// TIME SPENT: 5 hours 45 minutes
//-----------------------------------------------------------*/

#include <iostream>
// Import the Student header file here
// -->
#include <string>
#include <stdio.h>
#include "Student.h"

using namespace std;

int main()
{
    // Declare variables where you will store
    // inputs from user
    // -->
    //for first student
    string firstStudent_fName;
    string firstStudent_lName;

    //for second student
    string secondStudent_fName;
    string secondStudent_lName;
    string secondStudent_major;
    string secondStudent_major_change;
    int secondStudent_gradePoints;
    int secondStudent_totalCredits;

    //looper
    int start, finish, incrementedby;



    // ==================== Test The Constructor 1 ====================

    // Prompt and ask the user for
    //
    //      firstName and lastName.
    //
    // of the first student. Store these inputs in the local variables
    // -->
    cout << "ENTER FIRST STUDENT INFORMATIONS";

    cout << "\nEnter first name: ";
    getline(cin, firstStudent_fName);

    cout << "Enter last name: ";
    getline(cin, firstStudent_lName);

    // Use the constructor 1 of Student with two arguments to create a
    // brand-new object called student1, by using firstName and lastName
    // -->
     Student* firstStudent = new Student(firstStudent_fName, firstStudent_lName);

    // Display the information of student1
    //
    // Please use the object and methods to retrieve the information. Do NOT
    // use the local varibales in this main function.
    //
    // The message template, the <> part should be replaced by the data
    // in student1:
    //
    //      FIRST STUDENT INFORMATIONS
    //      The name of the student is: <student1's fullname>
    //      Major is: <student1's major>
    //      The student's number of points is: <student1's points>
    //      Number of earned credits is: <student1's credits>
    //
    // -->
    cout << "\nFIRST STUDENT INFORMATIONS " << endl;

    cout << "\nThe name of the student is: ";
    cout << firstStudent->getFullName();
    cout << "\nMajor is: ";
    cout << firstStudent->getMajor();
    cout << "\nThe student's number of points is: ";
    cout << firstStudent->getGradePoints();
    cout << "\nNumber of earned credits is: ";
    cout << firstStudent->getCredits();


    // ==================== Test The Constructor 2 ====================

    // Prompt and ask the user for
    //
    //      firstName, lastName, studentMajor, studentCredits,
    //      studentGradePoints,
    //
    // of the second student. Store these inputs in the local variables
    // -->
    cout << "\nENTER SECOND STUDENT INFORMATIONS";

    cout << "\nEnter first name: ";
    getline(cin, secondStudent_fName);
    cout << "Enter last name: ";
    getline(cin, secondStudent_lName);
    cout << "Enter your major: ";
    getline(cin , secondStudent_major);
    cout << "Enter your grade points: ";
    cin >> secondStudent_gradePoints;
    cout << "Enter your total credits: ";
    cin >> secondStudent_totalCredits;

    // Use the constructor 2 of Student class, which has 5 parameters,
    // to create a brand-new object student2. Be careful of the order of
    // parameters.
    // -->
    Student* secondStudent = new Student(secondStudent_major, secondStudent_totalCredits , secondStudent_gradePoints, secondStudent_fName, secondStudent_lName);

    // Display the information of student2
    //
    // Please use the object and methods to retrieve the information. Do NOT
    // use the local varibales in this main function.
    //
    // The message template, the <> part should be replaced by the data
    // in student2:
    //
    //      SECOND STUDENT INFORMATIONS
    //      The name of the student is: <student2's fullname>
    //      Major is: <student2's major>
    //      The student's number of points is: <student2's points>
    //      Number of earned a is: <student2's credits>
    //
    // -->
    cout << "\nSECOND STUDENT INFORMATIONS " << endl;
    cout << "\nThe Name of the student is: ";
    cout << secondStudent->getFullName();
    cout << "\nMajor is: ";
    cout << secondStudent->getMajor();
    cout << "\nThe student's number of points is: ";
    cout << secondStudent->getGradePoints();
    cout << "\nNumber of earned credits: ";
    cout << secondStudent->getCredits();


    // ==================== Test changeMajor ====================

    // Use the helper function "changeMajor" to change the student2's major to
    // "International Affairs". After that, print the message as follows:
    //
    //     <student2's fullname> has changed majors to International Affairs
    //
    // -->
    secondStudent_major_change = "International Affairs";
    secondStudent->changeMajor(secondStudent_major_change);
    cout << "\n\n" << secondStudent->getFullName() << " has changed major to " << secondStudent->getMajor();


    // ==================== Test The loopHelper ====================

    // The following code is used to test your helper function loopHelper.
    // You don't have to modify it.

    cout << "\n\nSTUDENT HELPER FUNCTIONS\n" << endl;
    firstStudent->loopHelper(1, 30, 3);

    firstStudent->loopHelper(5, 28, 2);

    return 0;
}




